function _pad(i, length, padder)
{
	var s;
	
	s = i.toString();
	
	while (s.length < length)
	{
		s = padder + s;
	}
	
	return s;
}

function _rpad(i, length)
{
	var s;
	
	s = i.toString();
	
	while (s.length < length)
	{
		s += ' ';
	}
	
	return s;
}

function _thousandPad(num)
{
	// thx Elias Zamaria @ http://stackoverflow.com/a/2901298
	// NOTE: will work only for integers
	return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function _timePad(t)
{
	t = ~~(t);
	return ~~(t / 3600) + ":" + _pad(~~((t % 3600) / 60), 2, '0') + ":"+ _pad(t % 60, 2, '0');
}
