"use strict";

/**
 * @constructor
 */
var Screen2 = function()
{
}

Screen2.prototype.init = function(game)
{
}

Screen2.prototype.tick = function(game)
{
}

Screen2.prototype.draw = function(game)
{
}
