"use strict";

/** @type {Game} */
var game = new Game();

window.addEventListener('load', game.init.bind(game, window));
