var imageSmoothingEnabled = 0;
var mozImageSmoothingEnabled = 0;
var webkitImageSmoothingEnabled = 0;
var msImageSmoothingEnabled = 0;

var io = {};
io.connect = function(a){};
io.connect.on = function(a, b){};
io.connect.emit = function(a, b){};
io.listen = function(a){};
io.sockets = {};
io.sockets.socket = {};
